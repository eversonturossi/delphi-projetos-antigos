Title: Remote Administrator Client/Server
Description: This is a remote administrator that I worked on a few years ago but really have not done anything to in a long time. I'm not sure how complete it is but alot of the stuff works and it has alot of features. It does most everything except Remote Desktop which is really much better and the main reason I stopped making this code. But it has alot of good code in it and alot of hard work went into it so maybe there is a function or something in it that someone can use in one of there programs. If you find anything you can use or liked my code please post/vote so I know I didn't do it all for nothing. Any questions can be emailed to me at mrtrix@gmx.net
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=1727&lngWId=7

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
