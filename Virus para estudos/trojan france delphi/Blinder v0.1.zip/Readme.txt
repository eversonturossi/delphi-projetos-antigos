//- BLiNDER - Binder Example           -//

ok then, the basics on how a binder
works.

Basically a Binder consists of 2 files.
The builder and the Stub. The builder is 
basically what is used to make the final
executeable file. It joins everything
together into 1 package for you.

The stub, is what is used inside the
created executeable. It removes all the
files the builder added to it and then 
perform specific actions to those files
(in this case it executes them if the 
user wishes it to).

Blinder is very basic, it does exactly 
what it says on the tin and nothing more.
If you wanted, you could always add some
compression or encryption for the files 
attached, its up to you.


//- The End.                           -//
//- Created by : HaTcHeT               -//
//- Contact    : hatchet@e-freak.co.uk -//
//- Visit      : www.E-FrEaK.co.uk     -//