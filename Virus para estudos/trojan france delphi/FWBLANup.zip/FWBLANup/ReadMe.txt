FWB LAN Uploader example by TM
http://www.RecoilCrew.tk

This is just an Example of a FWB LAN Uploader in Delphi.
The Injection method is best suited for ASM, But i couldn't be bothered to do it in ASM
Maybe i'll port it over.

It's pretty neat, Tells the Client what OS the server is on.
To take control over a server, double click on an IP, Theres no Editor as it's source.

Good learning, 
Creds to Aphex for his Array2Int function