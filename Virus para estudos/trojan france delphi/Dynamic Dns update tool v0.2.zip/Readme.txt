Dynamic Dns update tool v0.2 by satan_addict
============================================
Syntax:
             updatedns.exe -dn -a [user] [pwd] [dns] [ip]
             -d for DynDns account
             -n for No-IP accounts
             -a auto Wan IP

e.g.: 
             updatedns.exe -d -a satan mypwd satan.serveftp.org
             updatedns.exe -d satan mypwd satan.serveftp.org 81.13.23.14



DYNDNS CODES:
============

Update Syntax Errors
badsys -> The system parameter given is not valid. Valid system parameters are dyndns, statdns and custom.
badagent -> The user agent that was sent has been blocked for not following these specifications or no user agent was specified.

Account-Related Errors
badauth  -> The username or password specified are incorrect.
!donator -> An option available only to credited users (such as offline URL) was specified, but the user is not a credited user.

Update Complete
good -> The update was successful, and the hostname is now updated.
nochg -> The update changed no settings, and is considered abusive. Additional nochg updates will cause the hostname to become blocked.

Hostname-Related Errors
notfqdn -> The hostname specified is not a fully-qualified domain name (not in the form hostname.dyndns.org or domain.com).
nohost -> The hostname specified does not exist (or is not in the service specified in the system parameter)
!yours -> The hostname specified exists, but not under the username specified.
abuse -> The hostname specified is blocked for update abuse.

Server Error Conditions
numhost -> Too many or too few hosts found
dnserr -> DNS error encountered

Emergency Conditions
911 -> There is a serious problem on our side, such as a database or DNS server failure. The client should stop updating until notified via the status page that the service is back up.


NO-IP CODES:
===========

status=0 -> no change
status=1 -> correct uptade
status=2 -> incorrect dns
status=3 -> incorrect password
status=4 -> incorrect username