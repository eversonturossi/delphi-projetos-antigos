Program - Supa Binder
Author - TM
Version - 0.1
Date - 15/12/2004

Description -
Just an Example Binder, Stub is ultra light, If Ported to ASM should
be super small ;)
If you use or learn from this code give credit wheres it due.
Enjoy

Disclaimer -
This software comes as-is without warranty.
You use this software at your at risk.
The Author nor any one else associated with
Supa Binder shall be liable for any damages or
data loss arising from the use of Supa Binder.
