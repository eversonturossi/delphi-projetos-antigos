  ----------------------------------------------------------------------------------
  ~~~~~~~~~~~~~~~~~
  . : IMPORTANT : . 
  ~~~~~~~~~~~~~~~~~ 

  Please note, I did not write all the code contained in LOMLib, I have bundled
  some of Aphex's units as well, as his code is very nice and I didnt wish to
  re-invent the wheel.

  SocketUnit.pas		{ Modified TClientSocket.Idle() to return boolean }
  ThreadUnit.pas
  AfxCodeHook.pas
  AfxCodehookOLD.pas
  ApplicationUnit.pas
  CompressionStreamUnit.pas
  FileUnit.pas

  ----------------------------------------------------------------------------------
  ~~~~~~~~~~~~~~~~~~~
  . : INFORMATION : . 
  ~~~~~~~~~~~~~~~~~~~ 

  This library is a basic core code library, in the past such library's have
  failed to become popular as they lacked good features, were difficult to use and added 
  a lot of filesize, but I have found them very useful in creating small file sized apps 
  quickly and cleanly.

  Hopefully the libraries ive written/recoded will provide some help/ease of use for
  future coders, so they can create some really kick ass software.

  ----------------------------------------------------------------------------------
  ~~~~~~~~~~~~~~~~~~~
  LOMLIB release 2.0
  ~~~~~~~~~~~~~~~~~~~

  Copyright - Use and abuse, but dont remove this header from code, and
              gimme a shoutout if you used it.

  Author: ~LOM~
  Website: www.lommage.co.uk
  Contact: mail@lommage.co.uk

  Updates:
  ~~~~~~~~

  TStrList[0.5]     :- Replacement for TStringList
  TIntList[0.1]     :- IntList (I use this for modifying and recording Socket ID's)
  TEditServer[0.1]  :- Quick edit server, based on TStrList Class, allows you
                       to create edit server code efficiently. (Also has
                       encryption).
  TBasicStream[0.1] :- Wrapper for Windows Readfile/Writefile routines.
  TMapStream[0.1]   :- Wrapper for Mapping a file

  13th September -
    Added TMapStream class

  12th September -
    Added class TBasicStream
    Added manipulation subroutines

  10th September -
    Added class TIntList
    Added class TEditServer

  ----------------------------------------------------------------------------------
  ~~~~~~~~~~~~~~~~~~~~~
  LOMWebLIB release 1.0
  ~~~~~~~~~~~~~~~~~~~~~

  Copyright - Use and abuse, but dont remove this header from code, and
              gimme a shoutout if you used it.

  Author: ~LOM~
  Website: www.lommage.co.uk
  Contact: mail@lommage.co.uk

  Updates:
  ~~~~~~~~

  TWebBrowse[0.1]    :- Standard interface for downloading txt/exe files from the
                        net using Aphex's SocketUnit.pas (pure winsock - no
                        wininet)
  TWebServer[0.1]    :- Really basic webserver (for serving files).
  TSocks4Server[0.1] :- Socks 4 component based on Aphex's Socks 4 example

  14th September -
    Added TWebServer 0.1
    Added TSocks4Server 0.1

  13th September -
    Added TWebBrowse 0.1
    
  ----------------------------------------------------------------------------------
  ~~~~~~~~~~~~~~~~~~~~~~~~~~
  LOMFindFileLIB release 1.0
  ~~~~~~~~~~~~~~~~~~~~~~~~~~

  Copyright - Use and abuse, but dont remove this header from code, and
              gimme a shoutout if you used it.

  Author: ~LOM~
  Website: www.lommage.co.uk
  Contact: mail@lommage.co.uk

  Updates:
  ~~~~~~~~

  TFindFile[0.1] :- Searches a directory and returns a list of files found
                    (is recursive)

  13th September -
    Added TFindFile Class

  ----------------------------------------------------------------------------------