i-worm.ooops by p0ke.
StrList component by positron.

http://positronvx.cjb.net
http://p0ke.no-ip.com

use at your own responsiblity.

note:
  ebot.res is included into source code.
  remove {$R ebot.res} to get rid of it.