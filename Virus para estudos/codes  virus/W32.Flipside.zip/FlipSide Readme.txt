 ## 
 ## FlipSide Worm 1.0 - Open Source Code
 ## Provided to public for education purposes
 ## 
 ## Created by p0ke.
 ## 
 ## Infection way based on HaTcHeT's open-source binder.
 ## Tho this worm is stubless.
 ## 
 ## This worm first install itself
 ## melt itself, and creates a thread
 ## that kills (regedit.exe, taskmgr.exe, iexplore.exe, notepad.exe)
 ## and creates a autostart key every second.
 ## 
 ## Then it starts scanning the system after *.exe and *.scr
 ## files.
 ## 
 ## It skips the C:\Winnt / C:\windows directory becouse it
 ## might fail on system files.
 ## 
 ## 
 ## 
 ## Modify this worm at your own responsibility.
 ## The author(s) cannot be held responsible for
 ## any kind of damange/system failure from this
 ## open source worm. This worm is provided to bring
 ## a understanding of worms for people who is intrested.
 ## This worm is for education purposes only.