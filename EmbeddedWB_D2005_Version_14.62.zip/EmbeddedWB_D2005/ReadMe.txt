bsalsa productions develop freeware solutions for users and programmers under "Borland Delphi" with "Microsoft Windows" OS. Our main product is the Embedded Web Browser component package. Most of its components were originally developed by Per Linds? Larsen.
Our package gives you a complete solution to develop and control Internet based application. It  allow you to create a customized Web browsing application, add Internet, file and network browsing, document viewing, and data downloading capabilities to your applications
In the package there are many component that answer the needs of the programmer from Internet web browsers, to applications web updating.
The components support all Borland Delphi versions from D5 to D2006 and we update our components often on a weekly basis.
Our guiding line is  easy use and implementation so, all the components are under one tab and the code implementation in with one line of code! In the package, we included a full featured demos so that programmers can easily understand "how to do what".
Our major goal are:

 Fast.
 Handy.
 Small.
 Freeware.


Please read the credits file to find "who did what�!!
If you use this componets or any code part you do it on your own responsibility!!
There is no guaranty what so ever for none!
Please credit the creators and the contributors of the components.

Check the mega demo for demonstration of the package capabilities.

We do need beta testers and developers and someone that can write a help file.

If you find the component useful, please e-mail some additional samples to post on this webpage, bug report/fix or suggestions for enhancements to bsalsa@bsalsa.no-ip.info

Web Site Address: http://www.bsalsa.com/index.html
Support : http://www.bsalsa.com/support.html
Forum in: http://www.bsalsa.com/forum/index.php
Install: D5, D6, D7 :http://www.bsalsa.com/ewb_install_d5_d7.html
Install: D2005/5 http://www.bsalsa.com/ewb_install_d200.html
Uninstall: http://www.bsalsa.com/ewb_uninstall.html

