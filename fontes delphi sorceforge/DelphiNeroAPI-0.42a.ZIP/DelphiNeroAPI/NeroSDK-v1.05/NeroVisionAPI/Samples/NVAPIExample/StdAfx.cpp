/******************************************************************************
|* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
|* ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
|* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
|* PARTICULAR PURPOSE.
|* 
|* Copyright 1995-2004 Ahead Software AG. All Rights Reserved.
|*-----------------------------------------------------------------------------
|* NeroSDK / NVAPIExample
|*
|* PROGRAM: SpeedComboBox.cpp
|*
|* PURPOSE: stdafx.cpp : source file that includes just the standard includes
|*          NVAPITes.pch will be the pre-compiled header
|*          stdafx.obj will contain the pre-compiled type information
******************************************************************************/

#include "stdafx.h"



