//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Wav.rc
//
#define IDBTN_STUB                      2
#define IDD_WMAGEN_DIALOG               102
#define IDBTN_GENERATE                  1000
#define IDLIST_PROFILES                 1001
#define IDD_WAV_SETTINGS                3000
#define IDCOMBO_FREQ                    3000
#define IDCHECK_REMEMBER_OPT            3001
#define IDCOMBO_SAMPLE_SIZE             3004
#define IDR_PLUGIN_NLSDATA              3004
#define IDCOMBO_CHANNELS                3005
#define IDD_INFO                        4003
#define IDEDIT_PATH                     4005
#define IDEDIT_TITLE                    4006
#define IDEDIT_ARTIST                   4007
#define IDCOMBO_GENRE                   4010
#define IDEDIT_DATA_FORMAT              4011
#define IDEDIT_FILE_SIZE                4012
#define IDEDIT_DATETIME                 4013
#define IDBTN_CUSTOM_FIRST              4100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        3005
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         3002
#define _APS_NEXT_SYMED_VALUE           3001
#endif
#endif
