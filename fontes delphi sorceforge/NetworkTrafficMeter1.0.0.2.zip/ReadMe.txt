NetworkTrafficMeter v1.0.0.2 forWindows 98,  Windows NT, XP, Vista and Wine

GNU GPL3 License  (General Public License)
Some Rights Reserved.

This product contains the following components:
  License.txt		-- License file
  ReadMe.txt		-- This file
  NetworkTrafficMeter.exe	-- Main program

You are free to copy and distribute this product. Don't remove
the license, original author and contact informations from the product.
If you don't agree with license then you have no rights to use it.
Please see the license file for more information.

This product is provided without charge so I can't provide any technical
support for it. However, if you find any problems, please e-mail me at
thomacepcg@gmail.com with a complete description of the problem.



About ThomAce's Software
------------------------------------------

I developing non-commercial Windows based prodcuts for home users.

For more information, please contact me at

ThomAce ( Tam�s Kamocsai )
E-mail: thomacepcg@gmail.com
Web Page: http://networktrafficm.sourceforge.net
Project Page: http://sourceforge.net/projects/networktrafficm

----


FEATURES:
------------------------------------------

- Monitoring your selected Down and Upload
- Basic informations about your network devices
- Current Down / Upload speed
- Total Down / Upload
- Avarage Down / Upload
- Peak Down / Upload
- Multiple language support
- Automatic value calculator for graphical bars
- Informations on miniBar
- Overlay miniBar

----


SUPPORTING:
------------------------------------------

- All of most network adapters
- Multiple languages
- Graphical demonstration of your bandwidth usage

----


MINIMAL SYSTEM REQUIREMENTS:
------------------------------------------

- PII 400MHz
- 7MB free memory
- Free space on hard drive
- Internet or network connection
- TCP or UDP protocol support.

----



Windows NT, XP and Vista are registered trademarks of Microsoft Corporation.