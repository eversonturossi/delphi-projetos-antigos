#include <stdio.h>

int main(int argc, char **argv)
{
    printf("++++ You can go nowhere from this point ++++\n");
    while(1){ sleep(2000); }
}

