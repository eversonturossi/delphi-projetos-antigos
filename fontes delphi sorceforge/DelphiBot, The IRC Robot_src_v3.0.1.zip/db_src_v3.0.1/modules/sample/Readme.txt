DelphiBot 3.0 API Interface

Here are two empty module prototypes for DelphiBot 3.0, 
you can customize them as long as you don't change the declarations.
You may compile them with FPC (Free Pascal Compiler) or DCC (Delphi Compiler).
Two platforms are supported: Win32 and Unix.

TODO: Implement events on 'GloalEvents.pas' using APIs on 'GlobalMethods.pas'.

Chose the 1rst version for multi-threaded operations. You will need to 
get strings via a PChar buffer and then convert. It's annoying but safe.
The other alternative is to use the 2nd version that uses aninternal buffer.
It's not recommended for multui-threaded processing since many processes may 
acess the buffer at the same time: 
USE IT IF YOU DON'T CREATE PROCESSES THAT USE STRINGS API'S INSIDE THE MODULE!!!
Remember that all DelphiBot API's are thread safe, it's due to the use of 
critical sections. Be carefull to prevent mutual blocking (2 or more processes waiting each other).

If you find a bug or what ever wrong, contact the author at 
mailto:devlopper@delphibot.com
