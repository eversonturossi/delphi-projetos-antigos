Auto SHH Tunnel Manager v. 0.0.2
------------------------------------
Copyright (C) 2006  Florian Eyben  (flosoft@orbie.de)

Project Page: http://autotunnel.sourceforge.net
See Changes.txt for changes in this version

-- This program is distributed under the terms of the GPL, WITHOUT ANY WARRANTIES! Please see LICENSE.TXT for more information! --

Plink.exe Version >= 0.58 is required by this release!!

If you tunnel ports through an SSH connection and require these tunnel connections to be active automatically as soon as you have network access, without any interaction from your side, then the Auto SSH Tunnel Manager is for you.
You can set up SSH connections to 21 different hosts, each with different username, password and SSH port. For each host you can define multiple port forwards (the number is limited by the capabilities of the used backend plink.exe). Those forwards are entered in the following format: local-port:remote-host:remote-port

This program is a frontend to plink.exe (available from.. and included in the binary and source distributions). It runs in the windows system tray, and has a single easy configuration window. As soon as a connection to the ssh server is possible, the tunnel link is established automatically.

You may place a shortcut to your autotunnel.exe in the Autostart programs menu folder if you want the Tunnel Manager to automatically start when windows starts.

For installation instructions see the file install.txt!

If you have any questions, ideas or bugreports, please contact me at flosoft@orbie.de

When sending bugreports, please be sure to send along the Log (Check "Log Enable" and "Show Log" Checkboxes). If you feel more comfortable, EDIT the log to LEAVE OUT SENSITIVE INFORMATION like username and host or PASSWORD !


USING THE PROGRAM:
-------------------

Start it by double clicking on autotunnel.exe
In the main window you select the connection number you want to edit settings for from the dropdown menu at the top. Usually for most users it will be enough to set up tunnel connection 0.
Then for each tunnel connection you must enter a username and host, the ssh port (usually 22) and the password (!! see the note below !!) for the user. After entering or changing any of these settings, YOU MUST CLICK ON "save" TO UPDATE THE CONFIGURATION used by the program.
Each tunnel connection must be activated if you want to have it automatically connected. You can do so by checking the "activate tunnel" checkbox.
If you check the "online" checkbox at the top of the main window, the program begins searching for available network connections, and will automatically connect the links. If this is not checked, then no link will be established, no matter if you have a network connection or not.
Unchecking the ONLINE checkbox, will disconnect all links. Use this method if you are having problems connecting, and you change settings. Then uncheck ONLINE before changing settings and then recheck it, after making the changes and clicking on "save".

If you have trouble connecting your tunnels, enable logging and look at the output from the remote host, which is displayed in the Log Window. Then pick a phrase the remote host sends, that indicates successful login (for example: "Welcome to xyz host!" or "user xyz logged in" or the shell prompt [user@host:~/]). Enter this phrase in the configuration field "Expect login string from remote".

************************
!!! IMPORTANT NOTE !!! The password is, in this version of the program, stored in plain text in the file sshtunnel.ini (normally in your windows directory on c: ). So make sure no one unauthorized can read this file (use file permissions, if you have windows NT, 2000 oder XP Pro). It is also a good practice to create a special user on the remote machine, which is just used for tunneling and has no other access rights. However do not set the login shell to /bin/false or similar, those programs terminate right away and the ssh connection immediately terminates, so it can not be used for tunneling! instead, write a simple c program that consists only of an infinite loop, compile it and use it as your login shell for the tunneling user account. (nsh.c implements such a simple shell replacement, it is included with the autotunnel program)
NOT storing the password on the disk is not possible yet because I think it would destroy the idea of setting up the tunnel automatically and without user interaction. If you think differently and password security is important for you, please e-mail me, and I might include an option to not store the password on disk.

An alternate way to authenticate without password, is using public key authentication. For this to work you need pageant. Configure pageant and the leave the password field blank.
************************

