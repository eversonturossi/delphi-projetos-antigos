//-----------------------------------------------------------------------------
//
// ImageLib Utility Toolkit Sources
// Copyright (C) 2000-2002 by Denton Woods
// Last modified: 05/15/2002 <--Y2K Compliant! =]
//
// Filename: src-ILUT/src/ilut_internal.c
//
// Description: Internal stuff for ILUT
//
//-----------------------------------------------------------------------------


#include "ilut_internal.h"

//#if !defined(__APPLE__)
	ILimage *ilutCurImage = NULL;
//#endif
