//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDC_BACK                        3
#define IDD_WIZARD                      101
#define IDE_WATERMARK                   102
#define IDI_DBTOOL                      102
#define IDE_HDRLOGO                     103
#define IDI_PROFILEGREEN                104
#define IDR_DEFAULT1                    104
#define IDI_PROFILEYELLOW               105
#define IDD_WELCOME                     106
#define IDI_PROFILERED                  106
#define IDD_SELECTDB                    107
#define IDD_OPENERROR                   108
#define IDD_FILEACCESS                  109
#define IDD_CLEANING                    110
#define IDD_PROGRESS                    111
#define IDD_FINISHED                    112
#define IDC_WATERMARK                   1000
#define IDC_TITLE                       1001
#define IDC_HDRLOGO                     1002
#define IDC_DBLIST                      1003
#define IDC_FILE                        1004
#define IDC_OTHER                       1005
#define IDC_ERRORTEXT                   1006
#define IDC_INUSE                       1007
#define IDC_BACKUP                      1008
#define IDC_AGGRESSIVE                  1009
#define IDC_ERASEHISTORY                1010
#define IDC_CHECKONLY                   1010
#define IDC_MARKREAD                    1011
#define IDC_PROGRESS                    1011
#define IDC_STATUS                      1012
#define IDC_STBACKUP                    1013
#define IDC_LAUNCHMIRANDA               1015
#define IDC_DBFILE                      1016
#define IDC_BACKUPFILE                  1017
#define IDC_CHECK1                      1018
#define IDC_CONVERTUTF                  1018
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
