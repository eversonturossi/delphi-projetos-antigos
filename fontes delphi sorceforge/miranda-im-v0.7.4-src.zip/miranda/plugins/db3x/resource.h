//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_NOTOALL                     3
#define IDD_INSTALLINI                  235
#define IDD_WARNINICHANGE               236
#define IDD_INIIMPORTDONE               237
#define IDC_ININAME                     1333
#define IDC_VIEWINI                     1334
#define IDC_SECURITYINFO                1335
#define IDC_SETTINGNAME                 1336
#define IDC_NEWVALUE                    1337
#define IDC_WARNNOMORE                  1338
#define IDC_DELETE                      1339
#define IDC_RECYCLE                     1340
#define IDC_NEWNAME                     1341
#define IDC_MOVE                        1342
#define IDC_LEAVE                       1343

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        269
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1657
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
