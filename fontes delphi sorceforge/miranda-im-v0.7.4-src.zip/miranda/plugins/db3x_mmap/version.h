#define __FILEVERSION_STRING        0,7,6,0
#define __VERSION_STRING            "0.7.6.0"
#define __VERSION_DWORD             0x00070600
