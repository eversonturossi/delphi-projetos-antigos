//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by avs.rc
//
#define ID_USE_DEFAULTS                 3
#define IDD_OPTIONS                     101
#define IDD_OPTIONS_PICTS               101
#define IDD_OPENSUBCLASS                102
#define IDD_AVATAROPTIONS               103
#define IDI_AVATAR                      104
#define IDD_SET_OWN_SUBCLASS            105
#define IDD_DIALOG1                     106
#define IDD_USER_AVATAR                 106
#define IDD_PROTO_AVATARS               107
#define IDD_OPTIONS_AVATARS             109
#define IDD_OPTIONS_OWN                 110
#define IDC_PROTOCOLS                   1001
#define IDC_CLIST                       1002
#define IDC_SETPROTOPIC                 1003
#define IDC_PROTOPIC                    1004
#define IDC_REMOVEPROTOPIC              1005
#define IDC_PROTOAVATARNAME             1006
#define IDC_CHECK1                      1007
#define IDC_PROTECTAVATAR               1007
#define IDC_SHOWWARNINGS                1007
#define IDC_PER_PROTO                   1007
#define IDC_CHANGE                      1008
#define IDC_MAKE_TRANSPARENT_BKG        1008
#define IDC_GROW                        1008
#define IDC_RESET                       1009
#define IDC_MAKE_GRAYSCALE              1009
#define IDC_AVATARNAME                  1010
#define IDC_MAKE_GRAYSCALE2             1010
#define IDC_SET_MAKE_SQUARE             1010
#define IDC_HIDEAVATAR                  1011
#define IDC_DELETE                      1012
#define IDC_SIZELIMIT                   1012
#define IDC_SIZELIMITSPIN               1013
#define IDC_MAKETRANSPBKG               1013
#define IDC_GUESS_LEVEL                 1014
#define IDC_BKG_NUM_POINTS              1014
#define IDC_COMBO1                      1015
#define IDC_BKG_NUM_POINTS_SPIN         1015
#define IDC_BKG_COLOR_DIFFERENCE        1016
#define IDC_SIZELIMITSPIN3              1017
#define IDC_BKG_COLOR_DIFFERENCE_SPIN   1017
#define IDC_BKG_NUM_POINTS_L            1018
#define IDC_BKG_COLOR_DIFFERENCE_L      1019
#define IDC_MAKE_TRANSP_PROPORTIONAL    1020
#define IDC_MAKE_MY_AVATARS_TRANSP      1021
#define IDC_MAKE_SQUARE                 1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
