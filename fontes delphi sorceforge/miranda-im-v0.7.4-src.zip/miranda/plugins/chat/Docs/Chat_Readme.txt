----------------------------oOo----------------------------

                      Chat v 0.3.1.6

        Released 2004-05-26, last updated 2005-08-19

------------------------------------------------------------

Important information
----------

#1	This plugin provides a groupchat interface for any protocol that wish to use it. 

#2	End users need not worry about anything more than setting your preferences in

#3	Developers can take a look at the included m_chat.h for
	an introduction on how to use it. Feel free to contact me if you need more 
	information on how to get it working.



Change log
----------  

Please go to:
http://www.miranda-im.org/download/details.php?action=viewlog&id=1309



Author
---------  

My name is J�rgen Persson, also known as Matrix, I have been using 
Miranda IM since 2001 and so far I have been responsible for the IRC part and 
I am nowadays considered to be a 'core guy'.  If you wish to contact me you can e-mail 
me at: i_am_matrix at users dot sourceforge dot net. You can also join #miranda 
on the FreeNode network, where you can talk to me and other fans of Miranda IM. 



How to install
---------- 

Use an unzipper of choice (I use WinZip) and extract the files to the 'Plugins' 
directory of your Miranda IM installation. Please note that you must restart 
Miranda IM for the installation to complete. If you are upgrading to another 
version you will have to shut down Miranda before extracting the files 
or the process will fail.



Credits
----------  

Egodust, "The coding encyclopedia". Thanks! We miss You!!!
Valkyre, Thanks for the bold, italics and underline icons


Base Address
----------

0x54 110000 (matrix)  
  


Copyright and license
---------------------
Copyright (C) 2005  J�rgen Persson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.