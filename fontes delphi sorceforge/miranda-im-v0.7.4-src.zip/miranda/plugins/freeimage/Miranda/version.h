#define __FILEVERSION_STRING        0,7,10,0
#define __VERSION_STRING            "0.7.1.0"
#define __VERSION_DWORD             0x00070100
