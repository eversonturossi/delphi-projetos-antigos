<html>
<head>
<title>AjpdSoft - Obtenci�n de IP P�blica remotamente</title>
</head>
<body bgcolor="#FFFFFF" text="#000000">

<?php
  $encabezado = "<font size=\"2\" color=\"#008080\"><span style=\"font-family:
      Arial\"><b>AjpdSoft - Obtenci�n de IP P�blica remotamente</span></font><hr size=2
      width=\"100%\" align=center>";

  if (! (empty($opobtener))) 
  {    
    $encabezadotabla = "<form name=\"obteneripremota\" method=\"post\" action=\"obteneripremota.php\"> 
      <table border=\"1\" cellspacing=1 cellpadding=2 width=\"80%\" style=\"font-size: 8pt\"><tr>
      <td width=\"100\"><span><font face=\"verdana\"><b>Usuario</b></font></span></td>
      <td width=\"200\"><span><font face=\"verdana\"><b>Otro dato</b></font></span></td>
      <td><font face=\"verdana\"><b>IP P�blica actual</b></font></td>
      <td><font face=\"verdana\"><b>Fecha cambio</b></font></td>
      </tr>";

    $link = @mysql_connect($servidor, $usuario, $contrasena)
      or die ("No se pudo conectar a la base de datos, int�ntelo en otro momento.");
    @mysql_select_db($bd, $link)
      or die ("No se pudo conectar a la base de datos, int�ntelo en otro momento.");
    $usuarioip = strtoupper($usuarioip);
    $sqlConsulta = "SELECT * FROM $tabla WHERE USUARIO = '$usuarioip' AND CONTRASENA = '$contrasenaip' limit 0,1";
    $sqlResultado = mysql_query($sqlConsulta);
    $existe = false;
    while ($row = mysql_fetch_array($sqlResultado))
    {      
      $existe = true;
      echo $encabezadotabla; 
      echo "<tr>";
      echo "<td><font face=\"verdana\">" . $row["USUARIO"] . "</font></td>";
      echo "<td><font face=\"verdana\">" . $row["NOMBRECOMPLETO"] . "</font></td>";
      echo "<td><font face=\"verdana\">" . $row["IPACTUAL"] . "</font></td>";
      echo "<td><font face=\"verdana\">" . $row["FECHACAMBIO"]. "</font></td>";
      echo "</tr>";
    }
    echo "</table></form>";
    if (! ($existe))
    {
      echo "El usuario no existe o la contrase�a es incorrecta.";
    }
  }  
  else
  {
    $formulariopeticiondatos = "<form method=\"POST\" action=\"obteneripremota.php\">
  <table width=\"36%\"  border=\"1\">
    <tr>
      <td><span class=\"Estilo8\">IP Servidor </span></td>
      <td><input name=\"servidor\" type=\"text\" id=\"servidor\" value=\"hl21.dinaserver.com\" size=\"20\" maxlength=\"25\"></td>
    </tr>
    <tr>
      <td><span class=\"Estilo8\">Base datos </span></td>
      <td><input name=\"bd\" type=\"text\" id=\"bd\" value=\"avisoip\" size=\"20\" maxlength=\"100\"></td>
    </tr>
    <tr>
      <td>Tabla</td>
      <td><input name=\"tabla\" type=\"text\" id=\"tabla\" value=\"ip\" size=\"20\" maxlength=\"100\"></td>
    </tr>
    <tr>
      <td><span class=\"Estilo8\">Usuario BD </span></td>
      <td><input name=\"usuario\" type=\"text\" id=\"usuario\" value=\"avisoip\" size=\"20\" maxlength=\"100\"></td>
    </tr>
    <tr>
      <td><span class=\"Estilo8\">Contrase&ntilde;a BD </span></td>
      <td><input name=\"contrasena\" type=\"password\" id=\"contrasena\" value=\"avisoip\" size=\"20\" maxlength=\"20\"></td>
    </tr>
    <tr>
      <td width=\"38%\"><div align=\"right\" class=\"Estilo7\">Usuario</div></td>
      <td width=\"62%\"><input name=\"usuarioip\" type=\"text\" id=\"usuarioip\" size=\"20\" maxlength=\"25\"></td>
    </tr>
    <tr>
      <td><div align=\"right\" class=\"Estilo7\">Contrase&ntilde;a</div></td>
      <td><input name=\"contrasenaip\" type=\"password\" id=\"contrasenaip\" size=\"20\" maxlength=\"20\"></td>
    </tr>
    <tr>
      <td colspan=\"2\"><div align=\"center\">
        <input name=\"opobtener\" type=\"submit\" id=\"opobtener\" value=\"Obtener IP P&uacute;blica\">
      </div></td>
    </tr>
  </table></form>";
    echo $formulariopeticiondatos;
  }
?>

</body>
</html>